import xbmc

try: xbmc.executebuiltin('XBMC.RunScript(special://home/addons/service.iiNT3LiiSoull3ss/iiNT3LiiFiiND.py)')
except: pass

